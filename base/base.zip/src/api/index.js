/**
 * @file common request
 * @since 1.0.0
 * @author whzcorcd <whzcorcd@gmail.com>
 */
import business from '@/api/modules/business'

export default {
  business
}
